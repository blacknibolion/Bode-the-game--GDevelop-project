gdjs.Game_58_32BodeCode = {};
gdjs.Game_58_32BodeCode.localVariables = [];
gdjs.Game_58_32BodeCode.GDBackgroundMountain2Objects1= [];
gdjs.Game_58_32BodeCode.GDBackgroundMountain2Objects2= [];
gdjs.Game_58_32BodeCode.GDAlternativeSmallCastleObjects1= [];
gdjs.Game_58_32BodeCode.GDAlternativeSmallCastleObjects2= [];
gdjs.Game_58_32BodeCode.GDAlternativeSmallTowerObjects1= [];
gdjs.Game_58_32BodeCode.GDAlternativeSmallTowerObjects2= [];
gdjs.Game_58_32BodeCode.GDAlternativeTowerObjects1= [];
gdjs.Game_58_32BodeCode.GDAlternativeTowerObjects2= [];
gdjs.Game_58_32BodeCode.GDBackgroundMountain1Objects1= [];
gdjs.Game_58_32BodeCode.GDBackgroundMountain1Objects2= [];
gdjs.Game_58_32BodeCode.GDBackgroundMountain3Objects1= [];
gdjs.Game_58_32BodeCode.GDBackgroundMountain3Objects2= [];
gdjs.Game_58_32BodeCode.GDGreenHouse1Objects1= [];
gdjs.Game_58_32BodeCode.GDGreenHouse1Objects2= [];
gdjs.Game_58_32BodeCode.GDGreenHouse2Objects1= [];
gdjs.Game_58_32BodeCode.GDGreenHouse2Objects2= [];
gdjs.Game_58_32BodeCode.GDMayanPyramidObjects1= [];
gdjs.Game_58_32BodeCode.GDMayanPyramidObjects2= [];
gdjs.Game_58_32BodeCode.GDGreenHouseSmall2Objects1= [];
gdjs.Game_58_32BodeCode.GDGreenHouseSmall2Objects2= [];
gdjs.Game_58_32BodeCode.GDGreenHouseSmall1Objects1= [];
gdjs.Game_58_32BodeCode.GDGreenHouseSmall1Objects2= [];
gdjs.Game_58_32BodeCode.GDRedHouse1Objects1= [];
gdjs.Game_58_32BodeCode.GDRedHouse1Objects2= [];
gdjs.Game_58_32BodeCode.GDSmallCastleObjects1= [];
gdjs.Game_58_32BodeCode.GDSmallCastleObjects2= [];
gdjs.Game_58_32BodeCode.GDRedHouseSmall1Objects1= [];
gdjs.Game_58_32BodeCode.GDRedHouseSmall1Objects2= [];
gdjs.Game_58_32BodeCode.GDRedHouse2Objects1= [];
gdjs.Game_58_32BodeCode.GDRedHouse2Objects2= [];
gdjs.Game_58_32BodeCode.GDRedHouseSmall2Objects1= [];
gdjs.Game_58_32BodeCode.GDRedHouseSmall2Objects2= [];
gdjs.Game_58_32BodeCode.GDSmallTowerObjects1= [];
gdjs.Game_58_32BodeCode.GDSmallTowerObjects2= [];
gdjs.Game_58_32BodeCode.GDTowerObjects1= [];
gdjs.Game_58_32BodeCode.GDTowerObjects2= [];
gdjs.Game_58_32BodeCode.GDPyramidObjects1= [];
gdjs.Game_58_32BodeCode.GDPyramidObjects2= [];
gdjs.Game_58_32BodeCode.GDAlternativeBush2Objects1= [];
gdjs.Game_58_32BodeCode.GDAlternativeBush2Objects2= [];
gdjs.Game_58_32BodeCode.GDAlternativeBush1Objects1= [];
gdjs.Game_58_32BodeCode.GDAlternativeBush1Objects2= [];
gdjs.Game_58_32BodeCode.GDAlternativeBush3Objects1= [];
gdjs.Game_58_32BodeCode.GDAlternativeBush3Objects2= [];
gdjs.Game_58_32BodeCode.GDDeadTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDDeadTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDAlternativeBush4Objects1= [];
gdjs.Game_58_32BodeCode.GDAlternativeBush4Objects2= [];
gdjs.Game_58_32BodeCode.GDFrozenLongTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDFrozenLongTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDGreenSmallTree1Objects1= [];
gdjs.Game_58_32BodeCode.GDGreenSmallTree1Objects2= [];
gdjs.Game_58_32BodeCode.GDGreenSmallTree2Objects1= [];
gdjs.Game_58_32BodeCode.GDGreenSmallTree2Objects2= [];
gdjs.Game_58_32BodeCode.GDGreenSmallTree3Objects1= [];
gdjs.Game_58_32BodeCode.GDGreenSmallTree3Objects2= [];
gdjs.Game_58_32BodeCode.GDFrozenTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDFrozenTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDFrozenPineTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDFrozenPineTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDLongSnowTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDLongSnowTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDGreenSmallTree4Objects1= [];
gdjs.Game_58_32BodeCode.GDGreenSmallTree4Objects2= [];
gdjs.Game_58_32BodeCode.GDGreenSmallTree6Objects1= [];
gdjs.Game_58_32BodeCode.GDGreenSmallTree6Objects2= [];
gdjs.Game_58_32BodeCode.GDLongOrangeTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDLongOrangeTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDGreenSmallTree5Objects1= [];
gdjs.Game_58_32BodeCode.GDGreenSmallTree5Objects2= [];
gdjs.Game_58_32BodeCode.GDOrangeBush1Objects1= [];
gdjs.Game_58_32BodeCode.GDOrangeBush1Objects2= [];
gdjs.Game_58_32BodeCode.GDLongTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDLongTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDOrangeBush2Objects1= [];
gdjs.Game_58_32BodeCode.GDOrangeBush2Objects2= [];
gdjs.Game_58_32BodeCode.GDOrangeBush4Objects1= [];
gdjs.Game_58_32BodeCode.GDOrangeBush4Objects2= [];
gdjs.Game_58_32BodeCode.GDOrangeBush3Objects1= [];
gdjs.Game_58_32BodeCode.GDOrangeBush3Objects2= [];
gdjs.Game_58_32BodeCode.GDOrangePineTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDOrangePineTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDOrangeSmallTree1Objects1= [];
gdjs.Game_58_32BodeCode.GDOrangeSmallTree1Objects2= [];
gdjs.Game_58_32BodeCode.GDOrangeSmallTree3Objects1= [];
gdjs.Game_58_32BodeCode.GDOrangeSmallTree3Objects2= [];
gdjs.Game_58_32BodeCode.GDOrangeSmallTree2Objects1= [];
gdjs.Game_58_32BodeCode.GDOrangeSmallTree2Objects2= [];
gdjs.Game_58_32BodeCode.GDOrangeTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDOrangeTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDPineTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDPineTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDPalmTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDPalmTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDSnowPineTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDSnowPineTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDSnowTreeObjects1= [];
gdjs.Game_58_32BodeCode.GDSnowTreeObjects2= [];
gdjs.Game_58_32BodeCode.GDBush1Objects1= [];
gdjs.Game_58_32BodeCode.GDBush1Objects2= [];
gdjs.Game_58_32BodeCode.GDBush3Objects1= [];
gdjs.Game_58_32BodeCode.GDBush3Objects2= [];
gdjs.Game_58_32BodeCode.GDBush2Objects1= [];
gdjs.Game_58_32BodeCode.GDBush2Objects2= [];
gdjs.Game_58_32BodeCode.GDBush4Objects1= [];
gdjs.Game_58_32BodeCode.GDBush4Objects2= [];
gdjs.Game_58_32BodeCode.GDCactus2Objects1= [];
gdjs.Game_58_32BodeCode.GDCactus2Objects2= [];
gdjs.Game_58_32BodeCode.GDCactus1Objects1= [];
gdjs.Game_58_32BodeCode.GDCactus1Objects2= [];
gdjs.Game_58_32BodeCode.GDCactus3Objects1= [];
gdjs.Game_58_32BodeCode.GDCactus3Objects2= [];
gdjs.Game_58_32BodeCode.GDFullMoonObjects1= [];
gdjs.Game_58_32BodeCode.GDFullMoonObjects2= [];
gdjs.Game_58_32BodeCode.GDIronFenceObjects1= [];
gdjs.Game_58_32BodeCode.GDIronFenceObjects2= [];
gdjs.Game_58_32BodeCode.GDSunObjects1= [];
gdjs.Game_58_32BodeCode.GDSunObjects2= [];
gdjs.Game_58_32BodeCode.GDFloorObjects1= [];
gdjs.Game_58_32BodeCode.GDFloorObjects2= [];
gdjs.Game_58_32BodeCode.GDPlatformObjects1= [];
gdjs.Game_58_32BodeCode.GDPlatformObjects2= [];
gdjs.Game_58_32BodeCode.GDNewSprite2Objects1= [];
gdjs.Game_58_32BodeCode.GDNewSprite2Objects2= [];
gdjs.Game_58_32BodeCode.GDBallObjects1= [];
gdjs.Game_58_32BodeCode.GDBallObjects2= [];
gdjs.Game_58_32BodeCode.GDBallAnimObjects1= [];
gdjs.Game_58_32BodeCode.GDBallAnimObjects2= [];
gdjs.Game_58_32BodeCode.GDSpikeObjects1= [];
gdjs.Game_58_32BodeCode.GDSpikeObjects2= [];
gdjs.Game_58_32BodeCode.GDgroundObjects1= [];
gdjs.Game_58_32BodeCode.GDgroundObjects2= [];
gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1= [];
gdjs.Game_58_32BodeCode.GDGame_9595stateObjects2= [];
gdjs.Game_58_32BodeCode.GDSpawnPointObjects1= [];
gdjs.Game_58_32BodeCode.GDSpawnPointObjects2= [];
gdjs.Game_58_32BodeCode.GDNewTiledSpriteObjects1= [];
gdjs.Game_58_32BodeCode.GDNewTiledSpriteObjects2= [];
gdjs.Game_58_32BodeCode.GDGame_9595BorderObjects1= [];
gdjs.Game_58_32BodeCode.GDGame_9595BorderObjects2= [];
gdjs.Game_58_32BodeCode.GDPlayerObjects1= [];
gdjs.Game_58_32BodeCode.GDPlayerObjects2= [];


gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDSpawnPointObjects1Objects = Hashtable.newFrom({"SpawnPoint": gdjs.Game_58_32BodeCode.GDSpawnPointObjects1});
gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.Game_58_32BodeCode.GDBallObjects1});
gdjs.Game_58_32BodeCode.eventsList0 = function(runtimeScene) {

};gdjs.Game_58_32BodeCode.eventsList1 = function(runtimeScene) {

};gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_58_32BodeCode.GDPlayerObjects1});
gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.Game_58_32BodeCode.GDBallObjects1});
gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_58_32BodeCode.GDPlayerObjects1});
gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDSpikeObjects1Objects = Hashtable.newFrom({"Spike": gdjs.Game_58_32BodeCode.GDSpikeObjects1});
gdjs.Game_58_32BodeCode.eventsList2 = function(runtimeScene) {

};gdjs.Game_58_32BodeCode.eventsList3 = function(runtimeScene) {

};gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_58_32BodeCode.GDPlayerObjects1});
gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDGame_95959595BorderObjects1Objects = Hashtable.newFrom({"Game_Border": gdjs.Game_58_32BodeCode.GDGame_9595BorderObjects1});
gdjs.Game_58_32BodeCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Game_state"), gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1.length;i<l;++i) {
    if ( gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1[k] = gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1[i];
        ++k;
    }
}
gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Game_58_32BodeCode.GDBallObjects1);
/* Reuse gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1 */
{for(var i = 0, len = gdjs.Game_58_32BodeCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.Game_58_32BodeCode.GDBallObjects1[i].getBehavior("Animation").setAnimationName("pump");
}
}{for(var i = 0, len = gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1.length ;i < len;++i) {
    gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.Game_58_32BodeCode.GDSpawnPointObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Spawn balls") > 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDSpawnPointObjects1Objects);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_58_32BodeCode.GDSpawnPointObjects1 */
gdjs.Game_58_32BodeCode.GDBallObjects1.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Ball Spawn");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDBallObjects1Objects, (( gdjs.Game_58_32BodeCode.GDSpawnPointObjects1.length === 0 ) ? 0 :gdjs.Game_58_32BodeCode.GDSpawnPointObjects1[0].getPointX("")), (( gdjs.Game_58_32BodeCode.GDSpawnPointObjects1.length === 0 ) ? 0 :gdjs.Game_58_32BodeCode.GDSpawnPointObjects1[0].getPointY("")), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Ball Spawn");
}}

}


{


gdjs.Game_58_32BodeCode.eventsList0(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_58_32BodeCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_58_32BodeCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Game_58_32BodeCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Game_58_32BodeCode.GDPlayerObjects1[k] = gdjs.Game_58_32BodeCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Game_58_32BodeCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_58_32BodeCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_58_32BodeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_58_32BodeCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("roll");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_58_32BodeCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_58_32BodeCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Game_58_32BodeCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Game_58_32BodeCode.GDPlayerObjects1[k] = gdjs.Game_58_32BodeCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Game_58_32BodeCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_58_32BodeCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_58_32BodeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_58_32BodeCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("roll");
}
}}

}


{


gdjs.Game_58_32BodeCode.eventsList1(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Game_58_32BodeCode.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_58_32BodeCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDPlayerObjects1Objects, gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDBallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_58_32BodeCode.GDBallObjects1 */
/* Reuse gdjs.Game_58_32BodeCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_58_32BodeCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.Game_58_32BodeCode.GDBallObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Game_58_32BodeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_58_32BodeCode.GDPlayerObjects1[i].getBehavior("Scale").setScale(gdjs.Game_58_32BodeCode.GDPlayerObjects1[i].getBehavior("Scale").getScale() + (0.1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_58_32BodeCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs.Game_58_32BodeCode.GDSpikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDPlayerObjects1Objects, gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDSpikeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Game_state"), gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1);
/* Reuse gdjs.Game_58_32BodeCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_58_32BodeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_58_32BodeCode.GDPlayerObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1.length ;i < len;++i) {
    gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1[i].hide(false);
}
}}

}


{


gdjs.Game_58_32BodeCode.eventsList2(runtimeScene);
}


{


gdjs.Game_58_32BodeCode.eventsList3(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Game_Border"), gdjs.Game_58_32BodeCode.GDGame_9595BorderObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_58_32BodeCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDPlayerObjects1Objects, gdjs.Game_58_32BodeCode.mapOfGDgdjs_9546Game_959558_959532BodeCode_9546GDGame_95959595BorderObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Game_state"), gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1);
/* Reuse gdjs.Game_58_32BodeCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_58_32BodeCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_58_32BodeCode.GDPlayerObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1.length ;i < len;++i) {
    gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1[i].hide(false);
}
}}

}


};

gdjs.Game_58_32BodeCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_58_32BodeCode.GDBackgroundMountain2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBackgroundMountain2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeSmallCastleObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeSmallCastleObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeSmallTowerObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeSmallTowerObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeTowerObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeTowerObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDBackgroundMountain1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBackgroundMountain1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDBackgroundMountain3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBackgroundMountain3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouse1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouse1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouse2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouse2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDMayanPyramidObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDMayanPyramidObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouseSmall2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouseSmall2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouseSmall1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouseSmall1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouse1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouse1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDSmallCastleObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSmallCastleObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouseSmall1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouseSmall1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouse2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouse2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouseSmall2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouseSmall2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDSmallTowerObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSmallTowerObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDTowerObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDTowerObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDPyramidObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDPyramidObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDDeadTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDDeadTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush4Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush4Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDFrozenLongTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDFrozenLongTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDFrozenTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDFrozenTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDFrozenPineTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDFrozenPineTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDLongSnowTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDLongSnowTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree4Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree4Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree6Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree6Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDLongOrangeTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDLongOrangeTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree5Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree5Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDLongTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDLongTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush4Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush4Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangePineTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangePineTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeSmallTree1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeSmallTree1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeSmallTree3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeSmallTree3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeSmallTree2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeSmallTree2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDPineTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDPineTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDPalmTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDPalmTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDSnowPineTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSnowPineTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDSnowTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSnowTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDBush1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBush1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDBush3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBush3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDBush2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBush2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDBush4Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBush4Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDCactus2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDCactus2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDCactus1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDCactus1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDCactus3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDCactus3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDFullMoonObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDFullMoonObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDIronFenceObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDIronFenceObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDSunObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSunObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDFloorObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDFloorObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDPlatformObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDPlatformObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDNewSprite2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDNewSprite2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDBallObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDBallObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDBallAnimObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDBallAnimObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDSpikeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSpikeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDgroundObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDgroundObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDGame_9595stateObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDSpawnPointObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSpawnPointObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDGame_9595BorderObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDGame_9595BorderObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDPlayerObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDPlayerObjects2.length = 0;

gdjs.Game_58_32BodeCode.eventsList4(runtimeScene);
gdjs.Game_58_32BodeCode.GDBackgroundMountain2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBackgroundMountain2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeSmallCastleObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeSmallCastleObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeSmallTowerObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeSmallTowerObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeTowerObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeTowerObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDBackgroundMountain1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBackgroundMountain1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDBackgroundMountain3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBackgroundMountain3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouse1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouse1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouse2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouse2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDMayanPyramidObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDMayanPyramidObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouseSmall2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouseSmall2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouseSmall1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenHouseSmall1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouse1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouse1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDSmallCastleObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSmallCastleObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouseSmall1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouseSmall1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouse2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouse2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouseSmall2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDRedHouseSmall2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDSmallTowerObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSmallTowerObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDTowerObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDTowerObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDPyramidObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDPyramidObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDDeadTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDDeadTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush4Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDAlternativeBush4Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDFrozenLongTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDFrozenLongTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDFrozenTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDFrozenTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDFrozenPineTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDFrozenPineTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDLongSnowTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDLongSnowTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree4Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree4Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree6Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree6Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDLongOrangeTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDLongOrangeTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree5Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDGreenSmallTree5Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDLongTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDLongTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush4Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush4Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeBush3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangePineTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangePineTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeSmallTree1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeSmallTree1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeSmallTree3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeSmallTree3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeSmallTree2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeSmallTree2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDOrangeTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDPineTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDPineTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDPalmTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDPalmTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDSnowPineTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSnowPineTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDSnowTreeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSnowTreeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDBush1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBush1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDBush3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBush3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDBush2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBush2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDBush4Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDBush4Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDCactus2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDCactus2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDCactus1Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDCactus1Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDCactus3Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDCactus3Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDFullMoonObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDFullMoonObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDIronFenceObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDIronFenceObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDSunObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSunObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDFloorObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDFloorObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDPlatformObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDPlatformObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDNewSprite2Objects1.length = 0;
gdjs.Game_58_32BodeCode.GDNewSprite2Objects2.length = 0;
gdjs.Game_58_32BodeCode.GDBallObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDBallObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDBallAnimObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDBallAnimObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDSpikeObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSpikeObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDgroundObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDgroundObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDGame_9595stateObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDGame_9595stateObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDSpawnPointObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDSpawnPointObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDGame_9595BorderObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDGame_9595BorderObjects2.length = 0;
gdjs.Game_58_32BodeCode.GDPlayerObjects1.length = 0;
gdjs.Game_58_32BodeCode.GDPlayerObjects2.length = 0;


return;

}

gdjs['Game_58_32BodeCode'] = gdjs.Game_58_32BodeCode;
